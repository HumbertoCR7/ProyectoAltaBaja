<?php
include("conexion.php");
$con = conectar();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

    <title>Cursos</title>
</head>

<body>
    <header>
        <br>
        <h1>Ingresar Curso</h1>
        <br>
    </header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="index.php">Inicio</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="alumno1.php">Alumnos <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="curso1.php">Cursos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="alumno.php">Ingrese alumnos </a>
                </li>
                <li class="nav-item">
            </ul>
        </div>
    </nav>

    <main class="container">
        <form action="insertarcurso.php" method="POST">
            <h2>Inserte Nuevo Curso:</h2>

            <h4>Numero del Curso:</h4>
            <div class="col-12 col-md-5">
                <input type="text" required pattern="[0-9]+" class="form-control" name="Mcurso" placeholder="Escriba">
            </div>

            <h4>Nombre del Curso:</h4>
            <div class="col-12 col-md-5">
                <input type="text" required pattern="[a-zA-Z]+"  class="form-control" name="Ncurso" placeholder="Escriba">
            </div>

            <h4>Duración del Curso:</h4>
            <div class="col-12 col-md-5">
                <input type="text" required pattern="[0-9]+"  class="form-control" name="Hcurso" placeholder="Escriba">
            </div>

            <h4>Descripción del Curso:</h4>
            <div class="col-12 col-md-5">
                <input type="text" required pattern="[a-zA-Z]+" class="form-control" name="Descripcion" placeholder="Escriba">
            </div>

            <h4>Fecha de Inicio del Curso:</h4>
            <div class="col-12 col-md-3">
                <input type="date" required pattern="\d{4}-\d{2}-\d{2}" min="2023-06-01" max="2099-04-07" class="form-control" name="Incurso">
            </div>

            <h4>Fecha de Terminación del Curso:</h4>
            <div class="col-12 col-md-3">
                <input type="date" required pattern="\d{4}-\d{2}-\d{2}" min="2023-06-01" max="2099-04-07" class="form-control" name="Fcurso">
            </div>

            <div class="container mt-3">
                <button class="btn btn-primary">Guardar</button>
            </div>
        </form>
    </main>

    <br>
    <footer>
        <p>
            <h4>&copy;2020 Créditos de Actividades Complementarios. All rights reserved.</h4>
        </p>
    </footer>
</body>

</html>
