
<?php
// aqui inicia el dompdf, que nos permitira crear nuestro archivo en formato PDF
ob_start();
?>
<?php
include 'Ccurso.php'; // Incluir el archivo 'Ccurso.php' para obtener los datos necesarios
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>


    <title>Reporte</title>
</head>
<body>
    <header>
        <br>
        <h2>Reporte de materias</h2>
        <br>
    </header>

    
    <table class="table">
  
        <thead class="thead-dark">
            <th>Numero de Curso</th>
            <th>Nombre del Curso</th>
            <th>Duración del Curso</th>
            <th>Descripción del Curso</th>
            <th>Inicio del Curso</th>
            <th>Terminación del Curso</th>
            <th></th>
            <th></th>
        </thead>

        <tbody>
            <?php
            foreach($busca as $clave => $valor):
            ?>
            <tr>
                <td><?= $valor['Mcurso']; ?></td> <!-- Mostrar el número del curso -->
                <td><?= $valor['Ncurso']; ?></td> <!-- Mostrar el nombre del curso -->
                <td><?= $valor['Hcurso']; ?></td> <!-- Mostrar la duración del curso -->
                <td><?= $valor['Descripcion']; ?></td> <!-- Mostrar la descripción del curso -->
                <td><?= $valor['Incurso']; ?></td> <!-- Mostrar la fecha de inicio del curso -->
                <td><?= $valor['Fcurso']; ?></td> <!-- Mostrar la fecha de terminación del curso -->
                
            </tr>
        </tbody>
            <?php endforeach; ?>
    </table>
</body>
</html>
    
<?php
$html=ob_get_clean(); // Capturar la salida generada en el búfer y guardarla en la variable $html

require_once 'libreria/dompdf/autoload.inc.php';
use Dompdf\Dompdf;
$dompdf = new Dompdf();

$options = $dompdf->getOptions(); // Obtener las opciones de Dompdf
$options->set(array('isRemoteEnabled' => true)); // Permitir la carga de recursos remotos
$dompdf->setOptions($options); // Establecer las opciones actualizadas en Dompdf

$dompdf->loadHtml("$html"); // Cargar el contenido HTML en Dompdf

$dompdf->setpaper('letter'); // Establecer el tamaño del papel a 'letter' (carta)

$dompdf->render(); // Renderizar el documento PDF

$dompdf->stream("Archivo_.pdf", array("Attachment" => false)); // Enviar el archivo PDF generado al navegador para su visualización
?>  
