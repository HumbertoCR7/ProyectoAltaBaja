<?php 
    include("conexion.php"); // Incluir el archivo "conexion.php" para establecer la conexión con la base de datos
    $con = conectar(); // Establecer la conexión con la base de datos

    $Mcurso = $_GET['id']; // Obtener el valor del parámetro 'id' enviado a través de GET

    $sql = "DELETE FROM cursos WHERE Mcurso='$Mcurso'"; // Construir la consulta SQL para eliminar un registro de la tabla 'cursos' donde el valor de 'Mcurso' coincida con el valor recibido

    $query = mysqli_query($con, $sql); // Ejecutar la consulta SQL en la base de datos

    if($query){
        header("Location: curso1.php"); // Si la consulta se ejecuta correctamente, redirigir a la página "curso1.php"
    } else {
        // Si ocurre un error en la consulta, se puede agregar aquí un código de manejo de errores
    }
?>

