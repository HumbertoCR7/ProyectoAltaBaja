<?php
/**
 * Cargar y guardar una imagen en la base de datos.
 *
 * Este script recibe una imagen a través de un formulario y la guarda en la base de datos.
 * Se incluye el archivo "conexion.php" para establecer la conexión a la base de datos.
 * Se verifica si se ha cargado correctamente la imagen y se obtiene su contenido.
 * Luego se prepara una consulta SQL para insertar el contenido de la imagen en la tabla "alumno".
 * Se ejecuta la consulta y se verifica si se ha realizado correctamente.
 * Finalmente se muestra un mensaje indicando si la imagen se ha cargado correctamente o si ha ocurrido un error.
 */

// Incluir el archivo de conexión a la base de datos
include "conexion.php";

// Verificar si se ha enviado una solicitud POST y si se ha cargado una imagen
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["img"])) {
    $imagen = $_FILES["img"];
    
    // Verificar si se ha cargado correctamente la imagen
    if ($imagen["error"] === UPLOAD_ERR_OK) {
        $contenido = file_get_contents($imagen["tmp_name"]);
        
        // Insertar la imagen en la base de datos
        $sql = "INSERT INTO alumno (img) VALUES (?)";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("s", $contenido);
        $stmt->execute();
        
        echo "Imagen cargada correctamente.";
        
        $stmt->close();
    } else {
        echo "Error al cargar la imagen.";
    }
}

// Cerrar la conexión a la base de datos
$conexion->close();
?>

