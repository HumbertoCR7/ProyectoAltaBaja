<?php
/**
 * Agrega un nuevo curso a la base de datos.
 *
 * Este script recibe datos de un formulario enviado por el método POST para agregar un nuevo curso a la base de datos.
 * Se establece una conexión a la base de datos utilizando el archivo "conexion.php".
 * Los datos del curso se obtienen de las variables POST.
 * Se ejecuta una consulta SQL para insertar los datos del curso en la tabla "cursos".
 * Si la consulta se ejecuta correctamente, se redirige al usuario a la página "curso1.php".
 */

// Incluir el archivo de conexión a la base de datos
include("conexion.php");

// Establecer la conexión a la base de datos
$con = conectar();

// Obtener los datos del curso del formulario
$Mcurso = $_POST["Mcurso"];
$Ncurso = $_POST["Ncurso"];
$Hcurso = $_POST["Hcurso"];
$Descripcion = $_POST["Descripcion"];
$Incurso = $_POST["Incurso"];
$Fcurso = $_POST["Fcurso"];

// Consulta SQL para insertar los datos del curso en la tabla "cursos"
$sql = "INSERT INTO cursos (Mcurso, Ncurso, Hcurso, Descripcion, Incurso, Fcurso) VALUES ('$Mcurso', '$Ncurso', '$Hcurso', '$Descripcion', '$Incurso', '$Fcurso')";
$query = mysqli_query($con, $sql);

// Verificar si la consulta se ejecutó correctamente
if ($query) {
    // Redireccionar al usuario a la página "curso1.php"
    header("Location: curso1.php");
}
?>
