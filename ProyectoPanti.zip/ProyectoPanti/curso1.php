<?php
include 'Ccurso.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

    <title>Cursos 1</title>
</head>

<body>
    <header>
        <br>
        <h1>Lista de Cursos</h1>
        <br>
    </header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="index.php">Inicio</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="alumno1.php">Alumnos <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="curso1.php">Cursos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="alumno.php">Ingrese alumnos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="cursos.php">Ingrese cursos</a>
                </li>
            </ul>
        </div>
    </nav>

    <main class="container">
        <div class="table-responsive">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th>Numero de Curso</th>
                        <th>Nombre del Curso</th>
                        <th>Duración del Curso</th>
                        <th>Descripción del Curso</th>
                        <th>Inicio del Curso</th>
                        <th>Terminación del Curso</th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($busca as $clave => $valor) : ?>
                        <tr>
                            <td><?= $valor['Mcurso']; ?></td>
                            <td><?= $valor['Ncurso']; ?></td>
                            <td><?= $valor['Hcurso']; ?></td>
                            <td><?= $valor['Descripcion']; ?></td>
                            <td><?= $valor['Incurso']; ?></td>
                            <td><?= $valor['Fcurso']; ?></td>
                            <td><a href="Actu_Cursos.php?id=<?= $valor['Mcurso'] ?>" class="btn btn-info">Editar</a></td>
                            <td><a href="Eliminar_Curso.php?id=<?= $valor['Mcurso'] ?>" class="btn btn-danger">Eliminar</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <a href="Horario.php"><button type="button" class="btn btn-outline-danger">Reporte de materias</button></a>
    </main>
</body>

</html>
