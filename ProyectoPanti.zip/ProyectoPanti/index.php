<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <style>
        body {
            padding-top: 20px;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        .card {
            margin-bottom: 20px;
        }
        footer {
            background-color: #343a40;
            color: #ffffff;
            text-align: center;
            padding: 10px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>INSTITUTO TECNOLÓGICO DE CHINÁ</h1>
        </div>
    </header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Inicio</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="alumno1.php">Alumnos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="curso1.php">Cursos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="alumno.php">Ingrese alumnos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="cursos.php">Ingrese cursos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="usuario.php">Mi perfil</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <main>
        <div class="container">
            <h1 class="mt-5">Catálogo de carreras</h1>
            <div class="row">
                <div class="col-sm-6 col-md-4">
                    <div class="card">
                        <img src="img/informatica.webp" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Ingeniería informática</h5>
                            <p class="card-text">La ingeniería informática es una disciplina en constante evolución que impulsa la innovación y la transformación digital en diversos sectores.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4">
                    <div class="card">
                        <img src="img/administracion.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Ingeniería en administración</h5>
                            <p class="card-text">La ingeniería en administración es una disciplina que busca aplicar principios de ingeniería para mejorar la eficiencia y el rendimiento de las organizaciones.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4">
                    <div class="card">
                        <img src="img/Agronomia.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Ingeniería en agronomía</h5>
                            <p class="card-text">La ingeniería en agronomía es una disciplina que busca impulsar la producción agrícola de manera eficiente y sostenible, teniendo en cuenta aspectos importantes como la conservación del medio ambiente y el desarrollo rural.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4">
                    <div class="card">
                        <img src="img/Gestion.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Ingeniería en gestión empresarial</h5>
                            <p class="card-text">La ingeniería en gestión empresarial es una disciplina que busca aplicar principios de ingeniería para mejorar el desempeño y la competitividad de las organizaciones.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4">
                    <div class="card">
                        <img src="img/Indrustias.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Ingeniería en industrias alimentarias</h5>
                            <p class="card-text">Las industrias alimentarias se dedican a la producción, procesamiento, distribución y comercialización de alimentos.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4">
                    <div class="card">
                        <img src="img/Biologia.webp" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Biología</h5>
                            <p class="card-text">La biología es una rama de la ciencia que se enfoca en el estudio de los seres vivos y los procesos relacionados con ellos.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <footer class="bg-dark text-light text-center py-3 mt-5">
        <h4>&copy;2020 Créditos de Actividades Complementarios. All rights reserved.</h4>
    </footer>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha384-3zjT4YFGxkLxRyhHJk42YyW/z4kSlh8s5vBfw4KBDhlTxX1qlslJjiF4WZjyPxYX" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js" integrity="sha384-3S4Uba3XcQyOaRLWexAazLa/y6ZWTYyJyxtF2V6YXLGpYV1RoHrzv7mB6oGrqQ0i" crossorigin="anonymous"></script>
</body>
</html>
