<?php
/**
 * Agrega un nuevo alumno a la base de datos.
 *
 * Este script recibe datos de un formulario enviado por el método POST para agregar un nuevo alumno a la base de datos.
 * Se establece una conexión a la base de datos utilizando el archivo "conexion.php".
 * Los datos del alumno se obtienen de las variables POST.
 * Se ejecuta una consulta SQL para insertar los datos del alumno en la tabla "alumno".
 * Si la consulta se ejecuta correctamente, se redirige al usuario a la página "alumno1.php".
 */

// Incluir el archivo de conexión a la base de datos
include("conexion.php");

// Establecer la conexión a la base de datos
$con = conectar();

// Obtener los datos del alumno del formulario
$Matricula = $_POST["Matricula"];
$Nombres = $_POST["Nombres"];
$ApePaterno = $_POST["ApePaterno"];
$ApeMaterno = $_POST["ApeMaterno"];
$FNacimiento = $_POST["FNacimiento"];

// Procesar la imagen
$img = $_FILES['img']['name'];
$img_tmp = $_FILES['img']['tmp_name'];
$img_path = "uploads/" . $img;
move_uploaded_file($img_tmp, $img_path);

// Consulta SQL para insertar los datos del alumno en la tabla "alumno"
$sql = "INSERT INTO alumno (Matricula, Nombres, ApePaterno, ApeMaterno, FNacimiento, img) 
        VALUES ('$Matricula', '$Nombres', '$ApePaterno', '$ApeMaterno', '$FNacimiento', '$img_path')";
$query = mysqli_query($con, $sql);

// Verificar si la consulta se ejecutó correctamente
if ($query) {
    // Redireccionar al usuario a la página "alumno1.php"
    header("Location: alumno1.php");
}
?>
