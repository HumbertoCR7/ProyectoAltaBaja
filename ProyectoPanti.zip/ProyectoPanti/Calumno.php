<?php
$host = 'localhost'; // Nombre de host de la base de datos
$bd = 'proyectopanty'; // Nombre de la base de datos
$user = 'root'; // Nombre de usuario de la base de datos
$pass = '38939'; // Contraseña de la base de datos

try {
    $mbd = new PDO("mysql:host=$host;dbname=$bd", $user, $pass); // Crear una nueva instancia de PDO para establecer la conexión con la base de datos
    $busca = $mbd->query('SELECT * from alumno'); // Realizar una consulta SQL para seleccionar todos los registros de la tabla 'alumno'
} catch (PDOException $e) {
    // En caso de que ocurra una excepción de PDO, se captura y muestra el mensaje de error
    print "¡Error!: " . $e->getMessage() . "<br/>";
    die();
}
?>
