<?php
    // Incluir el archivo de conexión a la base de datos
    include("conexion.php");

    // Establecer la conexión con la base de datos
    $con = conectar();

    $id = $_GET['id'];

    $sql = "SELECT * FROM cursos WHERE Mcurso = '$id'";
    $query = mysqli_query($con, $sql);
    $row = mysqli_fetch_assoc($query);
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Actualizar</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>
<body>
<header>
    <br>
    <h1>INSTITUTO TECNOLÓGICO DE CHINÁ</h1>
    <br>
</header>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="index.php">Inicio</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="alumno1.php">Alumnos <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="curso1.php">Cursos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="alumno.php">Ingrese alumnos</a>
            </li>
        </ul>
    </div>
</nav>

<div class="container mt-5">
    <form action="Actu_Cursos1.php" method="POST">
        <input type="hidden" name="Mcurso" value="<?php echo $row['Mcurso'] ?>">

        <h4>Nombre del Curso:</h4>
        <div class="col-sm-12 col-md-5">
            <input type="text" required pattern="[A-Za-z]+" class="form-control" name="Ncurso" placeholder="Escriba" value="<?php echo $row['Ncurso'] ?>">
        </div>

        <h4>Duración del Curso:</h4>
        <div class="col-sm-12 col-md-5">
            <input type="text" required pattern="[0-9]+" class="form-control" name="Hcurso" placeholder="Escriba" value="<?php echo $row['Hcurso'] ?>">
        </div>

        <h4>Descripción del Curso:</h4>
        <div class="col-sm-12 col-md-5">
            <input type="text" required pattern="[A-Za-z]+" class="form-control" name="Descripcion" placeholder="Escriba" value="<?php echo $row['Descripcion'] ?>">
        </div>

        <h4>Fecha de Inicio del Curso:</h4>
        <div class="col-sm-12 col-md-3">
            <input type="date" required pattern="\d{4}-\d{2}-\d{2}" min="2023-06-01" max="2099-04-07" class="form-control" name="Incurso" value="<?php echo $row['Incurso'] ?>">
        </div>

        <h4>Fecha de Terminación del Curso:</h4>
        <div class="col-sm-12 col-md-3">
            <input type="date" required pattern="\d{4}-\d{2}-\d{2}" min="2023-06-01" max="2099-04-07" class="form-control" name="Fcurso" value="<?php echo $row['Fcurso'] ?>">
        </div>

        <input type="submit" class="btn btn-primary btn-block" value="Actualizar">
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
</body>
</html>

