<?php 
    include("conexion.php"); // Incluir el archivo de conexión a la base de datos
    $con=conectar(); // Establecer la conexión a la base de datos

    $Matricula=$_GET['id']; // Obtener el valor de la variable 'id' enviada a través de GET

    $sql="DELETE FROM alumno WHERE Matricula='$Matricula'"; // Crear una consulta SQL para eliminar un registro de la tabla 'alumno' donde la Matricula coincida con el valor obtenido
    $query=mysqli_query($con,$sql); // Ejecutar la consulta mediante la función mysqli_query()

    if($query){
        header("Location: alumno1.php"); // Si la consulta se ejecuta correctamente, redirigir al archivo alumno1.php
    }
?>
