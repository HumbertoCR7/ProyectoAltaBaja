<?php
function conectar(){
    $host = "localhost"; // Nombre de host de la base de datos
    $user = "root"; // Nombre de usuario de la base de datos
    $pass = "38939"; // Contraseña de la base de datos
    $bd = "proyectopanty"; // Nombre de la base de datos

    $con = mysqli_connect($host, $user, $pass, $bd); // Establecer la conexión con la base de datos

    mysqli_select_db($con, $bd); // Seleccionar la base de datos

    return $con; // Devolver la conexión establecida

    // Verificar si hay errores de conexión
    if ($conexion->connect_error) {
        die('Error de conexión: ' . $conexion->connect_error);
    }
}
?>

