<?php
// Configuración de la base de datos
$host = "localhost"; // Nombre de host de la base de datos
$user = "root"; // Nombre de usuario de la base de datos
$pass = "38939"; // Contraseña de la base de datos
$bd = "proyectopanty"; // Nombre de la base de datos

// Conexión a la base de datos
$con = new mysqli($host , $user, $pass, $bd);
if ($con->connect_error) {
    die("Error de conexión: " . $con->connect_error);
}

// Obtener los datos de la tabla
$sql = "SELECT * FROM alumno";
$result = $con->query($sql);

// Guardar los datos en un array asociativo
$alumnos = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $alumnos[] = $row;
    }
}

// Cerrar la conexión a la base de datos
$con->close();
?>

<!-- Aquí empieza el código HTML -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Alumnos</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
</head>
<header>
        <br>
        <h1>Lista de alumnos</h1>
        <br>
    </header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="index.php">Inicio</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="alumno1.php">Alumnos <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="curso1.php">Cursos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="alumno.php">Ingrese alumnos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="cursos.php">Ingrese cursos</a>
                </li>
            </ul>
        </div>
    </nav>
<body>
    <main class="container">
        <div class="table-responsive">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th>Matrícula</th>
                        <th>Nombre</th>
                        <th>Apellido Paterno</th>
                        <th>Apellido Materno</th>
                        <th>Fecha de Nacimiento</th>
                        <th>Imagen del Perfil</th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($alumnos as $alumno) : ?>
                        <tr>
                            <td><?= $alumno['Matricula']; ?></td>
                            <td><?= $alumno['Nombres']; ?></td>
                            <td><?= $alumno['ApePaterno']; ?></td>
                            <td><?= $alumno['ApeMaterno']; ?></td>
                            <td><?= $alumno['FNacimiento']; ?></td>
                            <td><img src="<?= $alumno['img']; ?>" alt="Imagen del perfil" width="200"></td>
                            <td><a href="actualizar1.php?id=<?= $alumno['Matricula']; ?>" class="btn btn-info">Editar</a></td>
                            <td><a href="eliminar.php?id=<?= $alumno['Matricula']; ?>" class="btn btn-danger">Eliminar</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>

