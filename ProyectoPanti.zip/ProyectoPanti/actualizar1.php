<?php 
include("conexion.php"); // Incluir el archivo "conexion.php" para establecer la conexión con la base de datos
$con = conectar(); // Establecer la conexión con la base de datos

$id = $_GET['id'];

$sql = "SELECT * FROM alumno WHERE Matricula='$id'";
$query = mysqli_query($con, $sql);

$row = mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/style.css" rel="stylesheet">
    <title>Actualizar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <link rel="stylesheet" href="../CSS/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
</head>
<body>
<header>
    <br>
    <h1>INSTITUTO TECNOLOGICO DE CHINÁ</h1>
    <br>
</header>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="index.php">Inicio</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="alumno1.php">Alumnos <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="curso1.php">Cursos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="alumno.php">Ingrese alumnos </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="cursos.php">Ingrese cursos</a>
            </li>
        </ul>
    </div>
</nav>

<main>
    <div class="container mt-5">
        <form action="actualizar.php" method="POST">
            <input type="hidden" name="Matricula" value="<?php echo $row['Matricula'] ?>">
            <h4>Nombre del Alumno:</h4>
            <input type="text" required pattern="[A-Za-z]+" class="form-control mb-3" name="Nombres" placeholder="Nombres" value="<?php echo $row['Nombres'] ?>">
            <h4>Apellido Paterno:</h4>
            <input type="text" required pattern="[A-Za-z]+" class="form-control mb-3" name="ApePaterno" placeholder="Ape Paterno" value="<?php echo $row['ApePaterno'] ?>">
            <h4>Apellido Materno:</h4>
            <input type="text" required pattern="[A-Za-z]+" class="form-control mb-3" name="ApeMaterno" placeholder="Ape Materno" value="<?php echo $row['ApeMaterno'] ?>">
            <h4>Fecha de Nacimiento:</h4>
            <input type="text" required pattern="\d{4}-\d{2}-\d{2}" min="1900-01-01" max="2023-04-07" class="form-control mb-3" name="FNacimiento" placeholder="AAAA-MM-DD" value="<?php echo $row['FNacimiento'] ?>">
            <input type="submit" class="btn btn-primary btn-block" value="Actualizar">
        </form>
    </div>
</main>
</body>
</html