<?php
    // Incluir el archivo de conexión a la base de datos
    include("conexion.php");

    // Establecer la conexión con la base de datos
    $con = conectar();

    // Obtener los valores enviados a través del método POST
    $Matricula = $_POST['Matricula'];
    $Nombres = $_POST["Nombres"];
    $ApePaterno = $_POST["ApePaterno"];
    $ApeMaterno = $_POST["ApeMaterno"];
    $FNacimiento = $_POST["FNacimiento"];
    $img = $_POST["img"];

    // Construir la consulta SQL para actualizar los datos del alumno en la tabla 'alumno'
    $sql = "UPDATE alumno SET Nombres = '$Nombres', ApePaterno = '$ApePaterno', ApeMaterno = '$ApeMaterno', FNacimiento = '$FNacimiento'
            WHERE Matricula = '$Matricula'";

    // Ejecutar la consulta SQL
    $query = mysqli_query($con, $sql);

    // Verificar si la consulta se ejecutó correctamente
    if ($query) {
        // Redireccionar al archivo 'alumno1.php' si la actualización fue exitosa
        header("Location: alumno1.php");
    }
?>


