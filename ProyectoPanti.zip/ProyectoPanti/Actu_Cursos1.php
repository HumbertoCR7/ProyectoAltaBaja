<?php
    // Incluir el archivo de conexión a la base de datos
    include("conexion.php");

    // Establecer la conexión con la base de datos
    $con = conectar();

    // Obtener los valores enviados a través del método POST
    $Mcurso = $_POST['Mcurso'];
    $Ncurso = $_POST["Ncurso"];
    $Hcurso = $_POST["Hcurso"];
    $Descripcion = $_POST["Descripcion"];
    $Incurso = $_POST["Incurso"];
    $Fcurso = $_POST["Fcurso"];

    // Construir la consulta SQL para actualizar los datos del curso en la tabla 'cursos'
    $sql = "UPDATE cursos SET Ncurso = '$Ncurso', Hcurso = '$Hcurso', Descripcion = '$Descripcion', Incurso = '$Incurso', Fcurso = '$Fcurso'
            WHERE Mcurso = '$Mcurso'";

    // Ejecutar la consulta SQL
    $query = mysqli_query($con, $sql);

    // Verificar si la consulta se ejecutó correctamente
    if ($query) {
        // Redireccionar al archivo 'curso1.php' si la actualización fue exitosa
        header("Location: curso1.php");
    }
?>

